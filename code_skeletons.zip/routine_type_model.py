class RoutineTypeModel:
    pass