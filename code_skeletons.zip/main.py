from src.chatbot_interface import Chatbot

if __name__=='__main__': Chatbot().start()