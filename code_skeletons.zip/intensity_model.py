class IntensityModel:
    pass