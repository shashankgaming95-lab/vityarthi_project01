class RoutineGenerator:
    pass