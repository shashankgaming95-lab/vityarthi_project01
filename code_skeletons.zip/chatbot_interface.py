class Chatbot:
    def start(self): pass