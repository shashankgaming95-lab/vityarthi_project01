class InputHandler:
    pass